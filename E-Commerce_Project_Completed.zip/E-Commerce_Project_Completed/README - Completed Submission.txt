E-COMMERCE WEBSITE – COMPLETED PROJECT PACKAGE

Project: E-Commerce Website
Version: 1.0
Date: 02 October 2026
Team ID: Not Provided

Technology Stack
- Frontend: React.js (VS Code)
- Backend: Java Spring Boot (IntelliJ IDEA)
- Database: MongoDB (MongoDB Compass)

Completed phases
1. Ideation Phase – problem statements, empathy map, brainstorming
2. Requirement Analysis – functional/non-functional requirements, user stories, data flow description, technology stack
3. Project Design Phase – problem-solution fit, proposed solution, solution architecture
4. Project Planning Phase – backlog, sprints, story points and tracker
5. Project Development Phase – UAT test cases and bug tracking template
6. Project Documentation – FSD documentation and final report
7. Project Demonstration – no demo assets were supplied; add screenshots/video/link when available

Notes
- Team ID and team member names were not supplied, so they are marked as “Not Provided”.
- Live URLs, credentials, screenshots and actual test execution measurements were not supplied and are marked for later insertion.
- AI/ML/Tableau/Power BI/Salesforce templates in the source package were not populated because they do not match the stated e-commerce technology stack.
